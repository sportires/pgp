<<<<<<< HEAD
# WalmartMx
+ Docs: https://walmartmx-sellercenter.readme.io/docs/createproduct
+ API Explorer: https://sellercenter.walmartmx.com.my/api/index?spm=a2o7i.10605172.0.0.55bba39fDRcmb6

# walmartmx_profile
+ Remove `profile_categories` and `magento_category` after stable version (WalmartMx)
=======
# m2-walmartmx
>>>>>>> 4aaf249785ee1d7ebadff487f83892beb74630dc
