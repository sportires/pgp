<?php

/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @category    Ced
 * @package     Ced_Amazon
 * @author      CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright   Copyright © 2019 CedCommerce. All rights reserved.
 * @license     EULA http://cedcommerce.com/license-agreement.txt
 */

namespace Ced\Integrator\Api\Data\Geocode;

interface StateInterface
{
    const LONG_NAME = "long_name";
    const SHORT_NAME = "short_name";
    const TYPE = "types";

    /**
     * Get Long Name
     * @return string
     */
    public function getLongName();

    /**
     * Get Short Name
     * @return string
     */
    public function getShortName();

    /**
     * Get Type List as Array
     * @return mixed
     */
    public function getType();
}
