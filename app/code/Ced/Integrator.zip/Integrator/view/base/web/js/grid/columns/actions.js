define(
    [
        'Magento_Ui/js/grid/columns/actions',
        'jquery',
        'Ced_Integrator/js/modal/popup',
        'vkbeautify',
        'highlight',
        'j2t'
    ], function (Actions, $, popup, vk, highlight, j2t) {
        'use strict';

        return Actions.extend(
            {
                defaults: {
                    bodyTmpl: 'Ced_Integrator/grid/cells/actions',
                },

                /**
                 * Applies specified action.
                 *
                 * @param   {String} actionIndex - Actions' identifier.
                 * @param   {Number} rowIndex - Index of a row.
                 * @returns {ActionsColumn} Chainable.
                 */
                applyAction: function (actionIndex, rowIndex) {
                    var action = this.getAction(rowIndex, actionIndex),
                        callback = this._getCallback(action);

                    if (action.confirm) {
                        this._confirm(action, callback);
                    } else if (action.popup) {
                        this._popup(action, callback);
                    } else if (action.disable) {
                        //Do nothing
                    } else {
                        callback();
                    }

                    return this;
                },

                /**
                 * Shows modal window.
                 *
                 * @TODO  implement loader
                 * @param {Object} action - Actions' data.
                 * @param {Function} callback - Callback that will be
                 *      invoked if action is confirmed.
                 */
                _popup: function (action, callback) {
                    var data = action.popup;
                    var dataType = data.type === undefined || data.type === '' ? 'xml' : data.type;
                    var download = false;

                    if (data.file !== undefined && data.file !== '') {
                        $.ajax(
                            {
                                url: data.file,
                                async: false,
                                dataType: "text",
                                type: 'GET',
                                success: function (response, status, request) {
                                    var size = request.responseText.length / 1024;

                                    // Skipping files larger than 500KB
                                    if (size < 500) {
                                        if (dataType === 'xml') {
                                            response = _.escape(vk.xml(response));
                                        } else if (dataType === 'json' && data.render !== 'html') {
                                            response = vk.json(response);
                                        }
                                    } else {
                                        download = true;
                                    }

                                    data.message = response;
                                }
                            }
                        );
                    }

                    if (download === false) {
                        var content = '<div style="max-height: 450px; overflow: auto;"><pre><code>' + data.message + '</code></pre></div>';
                        if (data.render === 'html' && dataType === 'json') {
                            var result = this.tryParseJSON(data.message);
                            if (result && Object.keys(result).length > 0) {
                                result = j2t.convert(result);
                            }
                            content = '<div style="max-height: 450px; overflow: auto;">' + result + '</div>';
                        }

                        popup(
                            {
                                title: data.title,
                                content: content,
                                actions: {
                                    confirm: callback
                                }
                            }
                        );

                        $(document).ready(
                            function () {
                                $('pre code').each(
                                    function (i, block) {
                                        var data = highlight.highlightBlock(block);
                                    }
                                );
                            }
                        );
                    } else {
                        var name = data.file.substring(data.file.lastIndexOf('/')+1);
                        var a = document.createElement('a');
                        a.href = window.URL.createObjectURL(new Blob([data.message], {type: "text/plain;charset=utf-8"}))
                        a.download = name;
                        a.style.display = 'none';
                        document.body.appendChild(a);
                        a.click();
                    }

                    this.hideLoader();
                },

                tryParseJSON: function (jsonString) {
                    try {
                        var o = JSON.parse(jsonString);

                        // Handle non-exception-throwing cases:
                        // Neither JSON.parse(false) or JSON.parse(1234) throw errors, hence the type-checking,
                        // but... JSON.parse(null) returns null, and typeof null === "object",
                        if (o && typeof o === "object") {
                            return o;
                        }
                    } catch (e) {
                    }

                    return false;
                }
            }
        );
    }
);
