# Integrator
+ Base package for integrations by Cedcommerce.com 

### TODO:
+ API
    + Analytics
+ Dashboard
+ License via OAuth
